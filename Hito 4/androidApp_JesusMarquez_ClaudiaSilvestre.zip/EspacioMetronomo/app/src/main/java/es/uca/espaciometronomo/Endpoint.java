package es.uca.espaciometronomo;

public class Endpoint {
    public static String getBooking()
    {
        return "http://10.0.2.2:3000/bookings/";
    }
}
