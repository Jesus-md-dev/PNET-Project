// Igualar Altura
function equalHeight() {
    document.getElementById("room1img").style.height = document.getElementById("room1").offsetHeight + "px";

    document.getElementById("room2img").style.height = document.getElementById("room2").offsetHeight + "px";

    document.getElementById("room3img").style.height = document.getElementById("room3").offsetHeight + "px";
}